[CmdletBinding()]
param(
  [string]$OutputPath
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSCommandPath
if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = Join-Path (Split-Path -Parent $root) 'peakgear-ai-lakehouse-resource-manager-v19.zip'
}

$outputDirectory = Split-Path -Parent $OutputPath
New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
Remove-Item -Force -ErrorAction SilentlyContinue $OutputPath

$excludedPatterns = @(
  '^\.terraform/',
  '^\.terraform\.lock\.hcl$',
  '(^|/)\.terraform\.tfstate\.lock\.info$',
  '(^|/)\.oci/',
  '^dist/',
  '(^|/)\.DS_Store$',
  '\.tfstate(\.|$)',
  '\.tfplan$',
  '\.tfvars(\.json)?$',
  '(^|/)crash(\..*)?\.log$',
  '\.generated\.zip$',
  'wallet.*\.(zip|b64)$',
  '\.pem$',
  '\.key$',
  '\.(p12|pfx|jks)$',
  '(^|/)\.env$'
)

$textExtensions = @(
  '.tf', '.yaml', '.yml', '.json', '.md', '.txt', '.sh', '.ps1', '.tpl'
)

$sensitiveContentPatterns = @(
  @{
    Name    = 'a private key'
    Pattern = '-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'
  },
  @{
    Name    = 'an embedded Object Storage pre-authenticated request'
    Pattern = '/p/[A-Za-z0-9_-]{20,}/'
  },
  @{
    Name    = 'a concrete OCI resource OCID'
    Pattern = '\bocid1\.(?:tenancy|user|compartment|instance|image|subnet|vcn|networksecuritygroup|autonomousdatabase)\.[A-Za-z0-9._-]{20,}\b'
  }
)

function Test-Excluded([string]$RelativePath) {
  foreach ($pattern in $excludedPatterns) {
    if ($RelativePath -match $pattern) { return $true }
  }
  return $false
}

function Assert-SafeSourceFile(
  [System.IO.FileInfo]$File,
  [string]$RelativePath
) {
  if ($textExtensions -notcontains $File.Extension.ToLowerInvariant()) {
    return
  }

  $content = [System.IO.File]::ReadAllText($File.FullName)
  if ($RelativePath -eq 'approved-artifacts.json') {
    $manifest = $content | ConvertFrom-Json
    $expectedKeys = @('peakgear_build_archive_url', 'gravitino_archive_url')
    $actualKeys = @($manifest.PSObject.Properties.Name)

    if (@(Compare-Object $expectedKeys $actualKeys).Count -ne 0) {
      throw 'approved-artifacts.json must contain only the reviewed Peak Gear and Gravitino artifact keys.'
    }

    $approvedPatterns = @{
      peakgear_build_archive_url = '^https://objectstorage\.us-ashburn-1\.oraclecloud\.com/p/[A-Za-z0-9_-]+/n/c4u04/b/ai-lh-build/o/build_dev\.zip$'
      gravitino_archive_url      = '^https://objectstorage\.us-ashburn-1\.oraclecloud\.com/p/[A-Za-z0-9_-]+/n/c4u04/b/ai-lh-build/o/gravitino-iceberg-rest-server-0\.7\.0-incubating-SNAPSHOT-bin\.zip$'
    }

    foreach ($key in $expectedKeys) {
      $value = [string]$manifest.$key
      if ($value -notmatch $approvedPatterns[$key]) {
        throw "approved-artifacts.json contains an unapproved value for $key."
      }
    }

    $content = $content -replace '/p/[A-Za-z0-9_-]{20,}/', '/p/<reviewed-central-artifact>/'
  }

  foreach ($entry in $sensitiveContentPatterns) {
    if ($content -match $entry.Pattern) {
      throw "Refusing to package $RelativePath because it contains $($entry.Name)."
    }
  }
}

$sourceFiles = @(
  Get-ChildItem -Path $root -Recurse -File | ForEach-Object {
    $relativePath = $_.FullName.Substring($root.Length + 1).Replace('\', '/')
    if (-not (Test-Excluded $relativePath)) {
      Assert-SafeSourceFile -File $_ -RelativePath $relativePath
      [PSCustomObject]@{
        File         = $_
        RelativePath = $relativePath
      }
    }
  }
)

$computeSource = [System.IO.File]::ReadAllText((Join-Path $root 'compute-app.tf'))
if ($computeSource -notmatch 'user_data\s*=\s*base64gzip\s*\(') {
  throw 'compute-app.tf must gzip cloud-init user data to remain below the OCI instance metadata limit.'
}

$bootstrapSource = [System.IO.File]::ReadAllText(
  (Join-Path $root 'scripts\bootstrap_lakehouse_vm.sh')
)
$startupHelperMatch = [regex]::Match(
  $bootstrapSource,
  '(?s)cat > "\$\{OPC_HOME\}/init/start-application-services\.sh" <<''EOF''\r?\n(?<Body>.*?)\r?\nEOF'
)
if (-not $startupHelperMatch.Success) {
  throw 'Unable to locate the generated Peak Gear service startup helper.'
}

$startupHelper = $startupHelperMatch.Groups['Body'].Value
$startupContract = @(
  '/home/opc/init/setenv.sh',
  'source /home/opc/ingestion/.env',
  'systemctl --user start adb-wallet.service',
  '/home/opc/ingestion/.adb_load_done',
  'build_service_image gravitino',
  'up --no-deps -d gravitino',
  'build_service_image ggsa',
  'systemctl --user start user-podman.service'
)
$previousPosition = -1
foreach ($step in $startupContract) {
  $position = $startupHelper.IndexOf($step, [System.StringComparison]::Ordinal)
  if ($position -lt 0) {
    throw "Peak Gear service startup helper is missing required step: $step"
  }
  if ($position -le $previousPosition) {
    throw "Peak Gear service startup helper has an invalid dependency order at: $step"
  }
  $previousPosition = $position
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open(
  $OutputPath,
  [System.IO.Compression.ZipArchiveMode]::Create
)

try {
  foreach ($sourceFile in $sourceFiles) {
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
      $archive,
      $sourceFile.File.FullName,
      $sourceFile.RelativePath,
      [System.IO.Compression.CompressionLevel]::Optimal
    ) | Out-Null
  }
} finally {
  $archive.Dispose()
}

$requiredEntries = @(
  'approved-artifacts.json',
  'artifacts.tf',
  'schema.yaml',
  'versions.tf',
  'main.tf',
  'variables.tf',
  'cloud-init/app.yaml',
  'scripts/bootstrap_lakehouse_vm.sh',
  'scripts/wait_for_bootstrap_callback.sh'
)

$verificationArchive = [System.IO.Compression.ZipFile]::OpenRead($OutputPath)
try {
  $entryNames = @{}
  foreach ($entry in $verificationArchive.Entries) {
    $entryNames[$entry.FullName] = $true
    if (Test-Excluded $entry.FullName) {
      throw "Refusing to release an archive containing excluded artifact: $($entry.FullName)"
    }
  }

  foreach ($requiredEntry in $requiredEntries) {
    if (-not $entryNames.ContainsKey($requiredEntry)) {
      throw "Resource Manager archive is missing required entry: $requiredEntry"
    }
  }
} finally {
  $verificationArchive.Dispose()
}

Write-Host "Created and verified $OutputPath"
